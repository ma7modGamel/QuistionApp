package com.example.xxpc.quizzapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class quesActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    int numOfQuestion;
    String[] answerArray = {"a", "a", "abc" + null, "a", "4","a", "a", "abc" + null, "a", "4"};
    String text;
    LinearLayout radioLayout;
    LinearLayout checkLayout;
    int degree;
    TextView tvAnswer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recyclyOfQuestions);
        tvAnswer=findViewById(R.id.tv_answer);


        RecyclerView.LayoutManager manager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        int[] photoQuizArray = {(R.drawable.q1), (R.drawable.q6), (R.drawable.q4), (R.drawable.q3),(R.drawable.q5),(R.drawable.q1), (R.drawable.q6), (R.drawable.q4), (R.drawable.q3), (R.drawable.q5)};
        recyclerView.setLayoutManager(manager);
        char[] typeQues = {'r', 'r', 'c', 'r', 'e','r', 'r', 'c', 'r', 'e'};
        numOfQuestion = getIntent().getIntExtra("numOfQuestion", 1);
        ArrayList<modelQuestions> arrayListOfQuestions = new ArrayList<>();
        for (int i = 0; i < numOfQuestion; i++) {
            arrayListOfQuestions.add(new modelQuestions(photoQuizArray[i], answerArray[i], typeQues[i]));
        }
        recyclerView.setAdapter(new quezAdabter(this, arrayListOfQuestions));

        tvAnswer.setText(0+" "+":"+" "+numOfQuestion);

    }

    public void sendAns(View view) {
        ShowQuisActivity showQuisActivity=new ShowQuisActivity();
        Toast.makeText(this, "0x"+showQuisActivity.degree, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dataIntent) {
        super.onActivityResult(requestCode, resultCode, dataIntent);
        if((requestCode==1)&&(resultCode== Activity.RESULT_OK)){
            degree =degree+ dataIntent.getIntExtra("degree", 0);

            Toast.makeText(this, "xxx "+degree, Toast.LENGTH_SHORT).show();

            tvAnswer.setText(degree+" "+":"+" "+numOfQuestion);
        }else
        {
            Toast.makeText(this, "rrrrrrr", Toast.LENGTH_SHORT).show();        }

    }

}

